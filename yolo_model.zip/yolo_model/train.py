from ultralytics import YOLO

# Load a model
# model = YOLO("yolo11n.yaml")  # build a new model from YAML
model = YOLO("/home/praveen/Desktop/Vinfotech/AI_and_DS/CV/project/backend/yolo/yolov8_model.pt")  # load a pretrained model (recommended for training)
# model = YOLO("yolo11n.yaml").load("yolo11n.pt")  # build from YAML and transfer weights

# Train the model
results = model.train(data="/home/praveen/Desktop/Vinfotech/AI_and_DS/CV/project/backend/yolo/data.yaml", epochs=25, imgsz=640)