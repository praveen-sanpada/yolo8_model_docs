from ultralytics import YOLO
import cv2

# Load a pretrained YOLO11n model
model = YOLO("/home/praveen/Desktop/Vinfotech/AI_and_DS/CV/project/backend/yolo/yolov8_model.pt")

# Run inference on 'bus.jpg' with arguments
res = model.predict("/home/praveen/Desktop/Vinfotech/AI_and_DS/CV/project/backend/yolo/test_data/bus-1-1.jpeg", save=True, imgsz=320, conf=0.5)
# res = model.predict("/home/praveen/Desktop/Vinfotech/AI_and_DS/CV/project/backend/yolo/test_data/car-t-1.jpeg", save=True, imgsz=320, conf=0.5)
# print(res[0])
frame=res[0].plot()
cv2.imshow("sfa",frame)
cv2.waitKey(0)